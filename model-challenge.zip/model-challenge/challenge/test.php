<?php

// print_r($_POST);
$data=$_POST;
  echo '<pre>';
print_r($data);
  echo '</pre>';


?>
