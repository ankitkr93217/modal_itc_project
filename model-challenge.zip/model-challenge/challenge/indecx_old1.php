<!DOCTYPE html>
<html lang="en">
<head>
  <title>Challenge</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">

  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->

  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script> -->

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js"></script>

    

<style >
      .imgcss{
        background-color: white;
       /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);*/
        height: 120px;
        width: 120px;
        border-radius:50%;
        background-size: cover;
        /*object-fit: cover;*/
        background-repeat: no-repeat;
        object-fit: fill;
        /*box-shadow:  0 0 10px  rgba(0,0,0,0.6);
        -moz-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
        -webkit-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
        -o-box-shadow: 0 0 10px  rgba(0,0,0,0.6);*/
      }
      
      .butn-css{
        background-color: black;
        color: white;
        border-radius:20px 20px;
        font-weight: bold;
        
      }
      .butn-css:Hover{
        background-color:#32CD32;
        color:white;
        font-weight: bold;
      }
      .iconcss{
        padding-left:3px;
        margin-left: 3px;
      } 
      .butn-with-p-icon{
        margin:5px 5px;
        font-weight: bold;
        background-color: white;
        color: black;
        border-radius:20px 20px;
        border: 2px solid #00FF00;
         
      }
      .butn-with-p-icon:Hover{
        background-color:#00FF00;
        color:white;
      }
      .txtclr{
        color: grey;
      }
      /*for cards DOWN*/
      .imgcss-card{
        margin-top:10px;
        margin-bottom:2px;
          background-color: white;
       /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);*/
        height:60px;
        width: 60px;
        border-radius:50%;
        background-size: cover;
        /*object-fit: cover;*/
        background-repeat: no-repeat;
        object-fit: fill;
        /*box-shadow:  0 0 10px  rgba(0,0,0,0.6);
        -moz-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
        -webkit-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
        -o-box-shadow: 0 0 10px  rgba(0,0,0,0.6);*/
      }
      .card{
        border-radius:10px;
        background-color:white;
        box-shadow:  0 0 10px  rgba(0,0,0,0.6);
        -moz-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
        -webkit-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
        -o-box-shadow: 0 0 10px  rgba(0,0,0,0.6);
      }
      /*for cards UP*/
      .profile-pic {
  position: relative;
  display: inline-block;
}

/*.profile-pic > .edit {
  display: block;
}*/

.edit {
  padding-top: 7px; 
  padding-right: 7px;
  position: absolute;
  right: 0;
  top: 0;
  /*display: none;*/
}

.edit a {
  color: #000;
}
 
</style>
<style class="example">
h4 {
  margin-bottom: 10px;
}
p.parsley-success {
  color: #468847;
  background-color: #DFF0D8;
  border: 1px solid #D6E9C6;
}
p.parsley-error {
  color: #B94A48;
  background-color: #F2DEDE;
  border: 1px solid #EED3D7;
}
</style>
  </head>
  <body>

    <div class="jumbotron text-center">
      <h1>Innovation Challenges</h1>

    </div>

    <div class="container">

      <button type="button" class="btn btn-lg butn-with-p-icon" data-toggle="modal" data-target="#innovation_challenges">Innovation Challenges</button>

    </div>

    <!-- Trigger the modal with a button -->


    <!-- Modal -->

    <div class="modal fade" id="innovation_challenges" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title" style="align-items:center; text-align: center;">Participating as a team/Indivisual</h4>
          </div>
          <div class="modal-body">
             
            <div style="display:flex;flex-direction: column ;align-items: center;">
              <div class="profile-pic"  >
                <img class="imgcss saturate " src="upload/arv.jpeg">
                <div style="background-color: grey; border-radius: 30px;" class="edit"><a href="#"><i style="color: white;"class="fa fa-pencil fa-lg"></i></a></div>
              </div>
            </div>
             
              <form  id="my-form" data-parsley-validate="">
              <div class="form-group ">
                <label class="txtclr">Team Name</label>
                <input type="text" name="team_name" class="form-control input-sm" id="team_name" data-parsley-required-message="Please insert Team Name" required>
              </div>
              <div class="row ">
                 
                <div class="card col-xs-5"  style="margin-top:20px;margin-left:23px; padding:auto auto;" >
                      <div class="card-block">  
                        <img class="imgcss-card" src="http://www.sportsjuggle.com/wp-content/uploads/2015/10/Eden-Hazard.jpg" alt="Card image">
                        <h4 class="card-subtitle text-muted">Support card subtitle</h4>
                        <p class="card-title">Eden Hazard</p>
                      </div>
                </div>
                <div class="card   col-xs-5" style="margin-top:20px;margin-left:23px;  padding:auto auto;"   >
                      <div class="card-block">
                        <img class="imgcss-card" src="http://www.sportsjuggle.com/wp-content/uploads/2015/10/Eden-Hazard.jpg" alt="Card image">
                        <h4 class="card-subtitle text-muted">Support card subtitle</h4>
                        <p class="card-title">Eden Hazard</p>
                      </div>    
                </div>
                <div class="card  col-xs-5" style="margin:20px 25px;" >
                      <div class="card-block">
                        <img class="imgcss-card" src="http://www.sportsjuggle.com/wp-content/uploads/2015/10/Eden-Hazard.jpg" alt="Card image">
                        <h4 class="card-subtitle text-muted">Support card subtitle</h4>
                        <p class="card-title">Eden Hazard</p>
                      </div>                     
                </div>
     
               
              </div> 
              <!-- fetch member details and show here- Down -->

              <!-- fetch member details and show here- UP -->

              <div >
                  <div style="display:flex;flex-direction:column;align-items:flex-end;">
                    <button id="" type="button" class="btn addnewform butn-with-p-icon">Add more Member<span  class="glyphicon glyphicon-plus   iconcss "></span></button>
                  </div>

                  <div id="newform">
                    
                  </div>
                  
                  <!-- <div><lebel class="txtclr">Member 2</lebel></div>
                  <div class="form-group">
                    <label  class="txtclr">Name</label>
                    <input type="text" class="form-control input-sm" name="member_2_name" id="member_2_name" data-parsley-required-message="Please insert Name." required >
                  </div>
                  <div class="form-group">
                    <label class="txtclr" >Email</label>
                    <input type="email" class="form-control input-sm" name="member_2_email" id="member_2_email" data-parsley-required-message="Please insert Email." required >
                  </div>
                 
                  <div><lebel class="txtclr">Member 3</lebel></div>
                  <div class="form-group">
                    <label class="txtclr">Name</label>
                    <input type="text" class="form-control input-sm" name="member_3_name" id="member_3_name" data-parsley-required-message="Please insert Name." required >
                  </div>
                  <div class="form-group">
                    <label class="txtclr">Email</label>
                    <input type="email" class="form-control input-sm" name="member_3_email" id="member_3_email" data-parsley-required-message="Please insert Email." required >
                  </div>
                  
                  <div><lebel class="txtclr">Member 4</lebel></div>
                  <div class="form-group">
                    <label class="txtclr" >Name</label>
                    <input type="text" class="form-control input-sm" name="member_4_name" id="member_4_name" data-parsley-required-message="Please insert Name." required >
                  </div>
                  <div class="form-group">
                    <label class="txtclr">Email</label>
                    <input type="email" class="form-control input-sm" name="member_4_email" id="member_4_email" data-parsley-required-message="Please insert Email." required >
                  </div>
                   
                  <div><lebel class="txtclr">Member 5</lebel></div>
                  <div class="form-group">
                    <label class="txtclr" >Name</label>
                    <input type="text" class="form-control input-sm"  name="member_5_name" id="member_5_name" data-parsley-required-message="Please insert Name." required >
                  </div>
                  <div class="form-group">
                    <label class="txtclr">Email</label>
                    <input type="email" class="form-control input-sm" name="member_5_email" id="member_5_email" data-parsley-required-message="Please insert Email." required >
                  </div> -->
                   
                
              </div>


            </div>
            <div class="modal-footer">
              <div style="align-items:center; text-align: center;">
                <p  class="txtclr">You can add upto 5 members.</p>
              <button  class="btn   name butn-css" id="add_member">Add Members</button>
              <!-- <button type="button" class="btn btn-danger" data-dismiss="modal"><strong>Close</strong></button> -->
              </div>
            </div>
            </form>
          </div>

        </div>
      </div>

<script type="text/javascript">
    // add row
    var counter = 2, limit =5;
    $(".addnewform").click(function () {
      alert("addnewform");
if(counter <= limit){
          var newform='';
              newform+='<div id="newsetFormRow">';         
              newform+='<div class="form-group">';
              newform+= '<label class="txtclr" ><strong>Name</strong></label>';
              newform+= '<input type="text" id="member'+counter+'_name"  class="form-control input-sm" name="member_name[]"  data-parsley-required-message="Please insert Name." required >';
              newform+='</div>';
              newform+='<div class="form-group">';
              newform+= '<label class="txtclr" ><strong>Email</strong></label>';
              newform+= '<input type="email" id="member'+counter+'_email" class="form-control input-sm" name="member_email[]" data-parsley-required-message="Please insert Email." required >';
              newform+='</div>';
              newform+='<div class="form-group " id="removenewform" style="align-items:right" >';
              newform+='<button type="button" class="btn butn-with-p-icon">Remove <span  class="glyphicon glyphicon-minus   iconcss "></span> '
                               '</button>';
              newform+='</div>';
              newform+='</div>';
              // newform+='<div style="display:flex;flex-direction:column;align-items:flex-end;">';
              // newform+='<button id="addnewform" type="button" class="btn butn-with-p-icon">Add more Member<span  class="glyphicon glyphicon-plus   iconcss "></span></button>';
              // newform+='</div>';

        $('#newform').append(newform);
        counter++;
      }
      else{
        alert("Not allowed");
      }
    });

    // remove row
    $(document).on('click', '#removenewform', function () {
      counter--
        $(this).closest('#newsetFormRow').remove();
    });
</script>

<script type="text/javascript">
$(function () {
  $('#my-form').parsley().on('field:validated', function() {
    var ok = $('.parsley-error').length === 0;
    $('.bs-callout-info').toggleClass('hidden', !ok);
    $('.bs-callout-warning').toggleClass('hidden', ok);
  })
  .on('form:submit', function() {
    return false; // Don't submit form for this demo
  });
});
</script>
 
<script>
var member_name, member_email;
  $(document).ready(function(){
    // $("#my-form").submit(function(){
    $("#add_member").click(function(e){
      e.preventDefault();
  /* 
var team_name = $("#team_name").val();
// var member_name = $(".member_name").val();
var member_email = $(".member_email").val();
var member_name = $("input[name='member_name[]']")
              .map(function(){return $(this).val();}).get();
alert(member_name);
*/
//var member_name = document.getElementsByName('member_name[]');
for (var i = 2; i <counter; i++) {
    alert("counter = "+counter+"\nName = "+$("#member"+i+"_name").val()+"\nEmail = "+$("#member"+i+"_email").val());
}

              
// for (var i =0; i< member_name.length; i++) {
//   var member_name = $(".member_name").val();
//   console.log(member_name[i]);
//   alert(member_name[i])
// }

// alert(member_name);
// var member_2_name = $("#member_2_name").val();
// var member_2_email = $("#member_2_email").val();
// var member_3_name = $("#member_3_name").val();
// var member_3_email = $("#member_3_email").val();
// var member_4_name = $("#member_4_name").val();
// var member_4_email = $("#member_4_email").val();
// var member_5_name = $("#member_5_name").val();
// var member_5_email = $("#member_5_email").val();

var alldata={
  team_name:team_name,
  member_name:member_name,
  member_email:member_email,
  // member_2_name:member_2_name,
  // member_2_email:member_2_email,
  // member_3_name:member_3_name,
  // member_3_email:member_3_email,
  // member_4_name:member_4_name,
  // member_4_email:member_4_email,
  // member_5_name:member_5_name,
  // member_5_email:member_5_email,
};




// Returns successful data submission message when the entered information is stored in database.
// var dataString = 'name1='+ name + '&email1='+ email + '&password1='+ password + '&contact1='+ contact;


// AJAX Code To Submit Form.
    $.ajax({
      type:"POST",
      url:"test.php",
      data:alldata,
      success:function(result){
      alert(result);
      }
    });

// ajax/insert_team_member.php

    });
  });

</script>


    </body>
    </html>


