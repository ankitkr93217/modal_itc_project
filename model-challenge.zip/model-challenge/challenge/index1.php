<!DOCTYPE html>
<html lang="en">
<head>
  <title>Challenge</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->

  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script> -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script> -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


</head>
<body>

<div class="jumbotron text-center">
  <h1>Innovation Challenges</h1>
   
</div>
  
<div class="container">

  <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#innovation_challenges">Innovation Challenges</button>
   
</div>

<!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  <div class="modal fade" id="innovation_challenges" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Participating as a team/Indivisual</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label  >Team Name</label>
            <input type="text" class="form-control" id="team_name">
          </div>
           
          <div class="form-group"><button type="button" class="btn btn-info collapsed" data-toggle="collapse" data-target="#toggle_form">Add Members</button></div>

          <!-- fetch member details and show here- Down -->

          <!-- fetch member details and show here- UP -->
           
          <div id="toggle_form" class="collapse">
          <form>
          <div><lebel>Member 1</lebel></div>
          <div class="form-group">
            <label  >Name</label>
            <input type="text" class="form-control" name="member_1_name" id="member_1_name">
          </div>
          <div class="form-group">
            <label >Email</label>
            <input type="email" class="form-control" name="member_1_email" id="member_1_email">
          </div>
          <hr>
          <div><lebel>Member 2</lebel></div>
          <div class="form-group">
            <label  >Name</label>
            <input type="text" class="form-control" name="member_2_name" id="member_2_name">
          </div>
          <div class="form-group">
            <label >Email</label>
            <input type="email" class="form-control" name="member_2_email" id="member_2_email">
          </div>
          <hr>
          <div><lebel>Member 3</lebel></div>
          <div class="form-group">
            <label  >Name</label>
            <input type="text" class="form-control" name="member_3_name" id="member_3_name">
          </div>
          <div class="form-group">
            <label >Email</label>
            <input type="email" class="form-control" name="member_3_email" id="member_3_email">
          </div>
          <hr>
          <div><lebel>Member 4</lebel></div>
          <div class="form-group">
            <label  >Name</label>
            <input type="text" class="form-control" name="member_4_name" id="member_4_name">
          </div>
          <div class="form-group">
            <label >Email</label>
            <input type="email" class="form-control" name="member_4_email" id="member_4_email">
          </div>
          <hr>
          <div><lebel>Member 5</lebel></div>
          <div class="form-group">
            <label  >Name</label>
            <input type="text" class="form-control" name="member_5_name" id="member_5_name">
          </div>
          <div class="form-group">
            <label >Email</label>
            <input type="email" class="form-control" name="member_5_email" id="member_5_email">
          </div>

          </form>
          </div>


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-info name" id="add_member">Add Members</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


  <script>
    
$(document).ready(function(){

$("#add_member").click(function(){

var member_1_name = $("#member_1_name").val();
var member_1_email = $("#member_1_email").val();
var member_2_name = $("#member_2_name").val();
var member_2_email = $("#member_2_email").val();
var member_3_name = $("#member_3_name").val();
var member_3_email = $("#member_3_email").val();
var member_4_name = $("#member_4_name").val();
var member_4_email = $("#member_4_email").val();
var member_5_name = $("#member_5_name").val();
var member_5_email = $("#member_5_email").val();

var alldata={
  member_1_name:member_1_name,
  member_1_email:member_1_email,
  member_2_name:member_2_name,
  member_2_email:member_2_email,
  member_3_name:member_3_name,
  member_3_email:member_3_email,
  member_4_name:member_4_name,
  member_4_email:member_4_email,
  member_5_name:member_5_name,
  member_5_email:member_5_email,
} 
// Returns successful data submission message when the entered information is stored in database.
// var dataString = 'name1='+ name + '&email1='+ email + '&password1='+ password + '&contact1='+ contact;
 

// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "ajax/insert_team_member.php",
dataType: "json",
data: alldata,
success: function(result){
alert(result);
}
});


 
});
});

  </script>

</body>
</html>


