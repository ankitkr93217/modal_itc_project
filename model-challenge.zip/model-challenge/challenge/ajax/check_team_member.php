<?php  require_once("db_config.php");

// echo $_POST;
$team_name=$_POST['team_name'];

$sql="SELECT name,COUNT(*) FROM `teamsdetail` WHERE `team`='".$team_name."' GROUP BY name ASC LIMIT 1;";
  
// $sql = "SELECT name FROM teamsdetail WHERE `team`='".$team_name."' AND `name` LIKE  ";
$result = $conn->query($sql);
 

$html='';
if ($result->num_rows > 0) {
  // output data of each row
	
  while($row = $result->fetch_assoc()) {
     // echo print_r($row);
  	// echo json_encode($row);

  	
  	$html.='<div class="card col-xs-5" style="margin-top:20px;margin-left:23px; padding:auto auto;">
                  <h4 class="txtclr">Member '.$row['member_number'].'</h4>
                      <div class="card-block" style="display:flex;justify-content:start;align-items: center;text-align:start; margin: 0 5px; padding:0 5px">

                        <div  >
                        <img class="imgcss-card" src="http://www.sportsjuggle.com/wp-content/uploads/2015/10/Eden-Hazard.jpg" alt="Card image">
                        </div>
                        <div style="margin-left:5px">
                        <h5 class="card-subtitle text-muted">'.$row['name'].'</h5>
                        <p class="card-title">'.$row['name'].'</p>
                        </div>
                      </div>
                </div>';

              

  }
  $html=$html;
  echo json_encode($html);



} else {
  echo "0 results";
}




?>