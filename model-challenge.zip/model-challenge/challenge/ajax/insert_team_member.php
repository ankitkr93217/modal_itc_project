<?php require_once("db_config.php");

// print_r($_POST);
// if(isset($_POST['test'])){
//     echo "string";
// }
// exit;

// $errorMSG = "";

if (empty($_POST["team_name"])) {
    $errorMSG = '<div class="alert alert-warning"><strong>Team Name</strong> is required.</div>';
} else {
    $team_name = $_POST["team_name"];
}
##
if (empty($_POST["member_name"])) {
    $errorMSG = "Name is required";
} else {
    $member_name = $_POST["member_name"];
}
if (empty($_POST["member_email"])) {
    $errorMSG .= '<div class="alert alert-warning">Email is required</div>';
// } else if(!filter_var($_POST["member_email"], FILTER_VALIDATE_EMAIL)) {
//     $errorMSG .= "<li>Invalid email format</li>";
}
else{
    $member_email = $_POST["member_email"];
}
 $member_number=$_POST['member_number'];
 // echo $member_number;exit();
foreach($member_name as $index => $name) {

    $obo_member_name=$name;
    $obo_member_email=$member_email[$index];
    $obo_member_number=$member_number[$index];

   
    $sql ="INSERT INTO  teamsdetail (`team`,`name`,`email`,`member_number`) VALUES ('".$team_name."','".$obo_member_name."','".$obo_member_email."','".$obo_member_number."')";    
    $result=$conn->query($sql); 

}
 echo $result;    
if ($result=== TRUE) {
  echo '<div class="alert alert-success alert-dismissible foralert text-center"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>New record created successfully</div>';
} else {
     echo '<div class="alert alert-success alert-dismissible foralert text-center"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Something Wrong, Please try again.</div>';
  // echo "Error: " . $sql . "<br>" . $conn->error;
}
 

// if(!empty($errorMSG)){

// 	// $msg = "Name: ".$name.", Email: ".$email.", Subject: ".$msg_subject.", Message:".$message;
//     $msg="Teams as well as members Created Succefully."
// 	echo json_encode(['code'=>200, 'msg'=>$msg]);

// 	exit;

// }


// echo json_encode(['code'=>404, 'msg'=>$errorMSG]);


?>